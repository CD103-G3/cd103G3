//飯團

var owl = $(".owl-carousel");
owl.owlCarousel({
  loop: true,
  margin: 90,
  nav: true,
  smartSpeed: 500,
  autoWidth: true,
  center: true,
  responsive: {
    0: {
      items: 1
    },
    320: {
      items: 1
    },
    600: {
      items: 2
    },
    960: {
      items: 3
    },
    1200: {
      items: 3
    }
  }
});

// owl.on('mousewheel', '.owl-stage', function (e) {
//     if (e.deltaY > 0) {
//         owl.trigger('next.owl');
//     } else {
//         owl.trigger('prev.owl');
//     }
//     e.preventDefault();
// });
